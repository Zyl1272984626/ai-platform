#!/usr/bin/env node

/**
 * SILK to WAV Converter
 * 使用 silk-wasm 库将 SILK 音频文件转换为 WAV 格式
 *
 * 用法: node silk-to-wav.js <input.silk> <output.wav>
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ES 模块中获取 __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// SILK 采样率（微信语音标准）
const SILK_SAMPLE_RATE = 24000;

// 从命令行获取参数
const inputFile = process.argv[2];
const outputFile = process.argv[3];

if (!inputFile || !outputFile) {
  console.error('用法: node silk-to-wav.js <input.silk> <output.wav>');
  console.error('示例: node silk-to-wav.js voice.silk voice.wav');
  process.exit(1);
}

// 解析为绝对路径
const inputPath = path.resolve(inputFile);
const outputPath = path.resolve(outputFile);

// 检查输入文件是否存在
if (!fs.existsSync(inputPath)) {
  console.error(`[ERROR] 输入文件不存在: ${inputPath}`);
  process.exit(1);
}

try {
  // 读取 SILK 文件
  const silkData = fs.readFileSync(inputPath);

  if (!silkData || silkData.length === 0) {
    console.error(`[ERROR] 读取文件失败或文件为空: ${inputPath}`);
    process.exit(1);
  }

  console.log(`[INFO] 读取 SILK 文件: ${inputFile} (${silkData.length} bytes)`);

  // 动态导入 silk-wasm
  const silkWasm = await import('silk-wasm');

  // 获取 decode 函数
  const decode = silkWasm.decode || silkWasm.default?.decode;
  if (typeof decode !== 'function') {
    console.error('[ERROR] silk-wasm 没有找到 decode 函数');
    process.exit(1);
  }

  // 使用 silk-wasm 解码
  const startTime = Date.now();
  const decodedResult = await decode(silkData, SILK_SAMPLE_RATE);
  const duration = Date.now() - startTime;

  // silk-wasm 返回 Uint8Array 或 ArrayBuffer
  let pcmData;
  if (decodedResult instanceof Uint8Array) {
    pcmData = decodedResult;
  } else if (decodedResult instanceof ArrayBuffer) {
    pcmData = new Uint8Array(decodedResult);
  } else if (decodedResult && decodedResult.data) {
    // 如果返回的是对象格式
    pcmData = decodedResult.data instanceof Uint8Array ? decodedResult.data : new Uint8Array(decodedResult.data);
  } else {
    console.error('[ERROR] decode 返回结果无效');
    process.exit(1);
  }

  console.log(`[INFO] 解码完成: PCM=${pcmData.byteLength} bytes, 耗时=${duration}ms`);

  // 添加 WAV 文件头
  const wavData = addWavHeader(pcmData, SILK_SAMPLE_RATE);

  // 写入 WAV 文件
  fs.writeFileSync(outputPath, Buffer.from(wavData));

  const inputSize = (silkData.length / 1024).toFixed(1);
  const outputSize = (wavData.length / 1024).toFixed(1);
  console.log(`[SUCCESS] 转换完成: ${inputFile} (${inputSize}KB) -> ${outputFile} (${outputSize}KB)`);

} catch (err) {
  console.error(`[ERROR] 转换失败: ${err.message}`);
  console.error(err.stack);
  process.exit(1);
}

/**
 * 将 PCM 数据封装为 WAV 格式
 * @param {Uint8Array} pcmData PCM 数据（16-bit signed little-endian）
 * @param {number} sampleRate 采样率
 * @returns {Uint8Array} WAV 格式数据
 */
function addWavHeader(pcmData, sampleRate) {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * bitsPerSample / 8;
  const blockAlign = numChannels * bitsPerSample / 8;
  const dataSize = pcmData.byteLength;
  const totalSize = 36 + dataSize + 8;

  const buffer = new Uint8Array(totalSize);
  const view = new DataView(buffer.buffer);

  let offset = 0;

  // RIFF chunk
  writeString(buffer, offset, 'RIFF');
  offset += 4;
  view.setUint32(offset, totalSize - 8, true);
  offset += 4;

  // WAVE format
  writeString(buffer, offset, 'WAVE');
  offset += 4;

  // fmt subchunk
  writeString(buffer, offset, 'fmt ');
  offset += 4;
  view.setUint32(offset, 16, true);
  offset += 4; // PCM format size
  view.setUint16(offset, 1, true);
  offset += 2; // PCM format
  view.setUint16(offset, numChannels, true);
  offset += 2; // mono
  view.setUint32(offset, sampleRate, true);
  offset += 4;
  view.setUint32(offset, byteRate, true);
  offset += 4;
  view.setUint16(offset, blockAlign, true);
  offset += 2;
  view.setUint16(offset, bitsPerSample, true);
  offset += 2;

  // data subchunk
  writeString(buffer, offset, 'data');
  offset += 4;
  view.setUint32(offset, dataSize, true);
  offset += 4;

  // PCM data
  buffer.set(pcmData, offset);

  return buffer;
}

function writeString(arr, offset, str) {
  for (let i = 0; i < str.length; i++) {
    arr[offset + i] = str.charCodeAt(i);
  }
}
